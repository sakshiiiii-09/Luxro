from django.db import models
from django.contrib.auth.models import User



class user(models.Model):
    uimage = models.ImageField(upload_to='image')
    ufname=models.CharField(max_length=50)
    uname=models.CharField(max_length=50)
    uemail=models.CharField(max_length=50)
    upass=models.CharField(max_length=50)
    ucpass=models.CharField(max_length=50)
    address=models.CharField(max_length=255)


class product(models.Model):
    CAT=(1,'footwears'),(2,'Clothes'),(3,'Accesories')
    pimage = models.ImageField(upload_to='image')
    name=models.CharField(max_length=50, verbose_name="product_name")
    brand=models.CharField(max_length=50, verbose_name="product_brand")
    gender=models.CharField(max_length=50, verbose_name="gender")
    price=models.FloatField()
    pdetails=models.CharField(max_length=1000, verbose_name="product_details")
    cat=models.IntegerField()
    is_active=models.BooleanField(default=True, verbose_name="Available")

class Cart(models.Model):
    uid=models.ForeignKey(User,on_delete=models.CASCADE, db_column="uid")
    pid=models.ForeignKey(product,on_delete=models.CASCADE,db_column="pid")
    qty=models.IntegerField(default=1)

class Order(models.Model):
    order_id=models.CharField(max_length=50)
    uid=models.ForeignKey(User,on_delete=models.CASCADE,db_column="uid")
    pid=models.ForeignKey(product,on_delete=models.CASCADE, db_column="pid")
    qty=models.IntegerField(default=1)

# class Billing(models.Model):
#     order_id = models.ForeignKey(product,on_delete=models.CASCADE,db_column="pid")
#     uid=models.ForeignKey(User,on_delete=models.CASCADE,db_column="uid")
#     ufname=models.CharField(max_length=50)
#     uadd=models.CharField(max_length=250)
#     zipcode=models.IntegerField()
#     city=models.CharField(max_length=50)
#     country=models.CharField(max_length=50)

# class Profile(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE) # Delete profile when user is deleted
#     image = models.ImageField(default='default.jpg', upload_to='profile_pics')

#     def __str__(self):
#         return f'{self.user.username} Profile' #show how we want it to be displayed
    
# class Wishlist(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE ,null=True)
#     product = models.ForeignKey(product, on_delete=models.CASCADE ,null=True)


# def __str__(self):
#         return self.user.username + "'s wishlist"

