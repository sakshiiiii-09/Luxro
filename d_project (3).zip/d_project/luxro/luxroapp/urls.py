from django.urls import path
from luxroapp import views


urlpatterns = [
    path('about/',views.about),
    path('home/',views.home),
    path('login',views.user_login),
    path('register',views.user_register),
    path('logout',views.user_logout),
    # path('cart',views.cart),
    path('pdetails/<pid>',views.product_details),
    path('products',views.products),
    path('checkout',views.checkout),
    path('pfilter/<cv>',views.pfilter),
    path('catfilter/<cv>/<g>',views.catfilter),
    path('sort/<sid>',views.sort),
    path('range',views.range),
    path('addtocart/<pid>',views.addtocart),
    path('viewcart',views.viewcart),
    path('remove/<cid>',views.remove),
    path('updateqty/<qv>/<cid>',views.updateqty),
    # path('wishlist',views.wishlist),
    # path('addtowishlist/<pid>',views.addtowishlist),
    # path('viewwishlist',views.viewwishlist),
    path('placeorder',views.placeorder),
    path('removeorder/<oid>',views.removeorder),
    path('makepayment',views.makepayment),
    path('genderfilter/<gid>',views.genderfilter),
    # path('add_to_wishlist/<pid>', views.add_to_wishlist, name='add_to_wishlist'),
    # path('wishlist/', views.wishlist, name='wishlist'),
    # path('remove_from_wishlist/<pid>', views.remove_from_wishlist, name='remove_from_wishlist'),
    path('search/', views.search, name='search'),
    # path('products/<str:gid>/<str:cv>/', views.get_products, name='get_products'),
    # path('add_to_wishlist/<int:product_id>/', views.add_to_wishlist, name='add_to_wishlist'),
    # path('gender/<str:gid>/subcat/<int:cv>/', views.gender_subcat_filter, name='gender_subcat_filter'),
    path('conformation/',views.conformation),

]

# username-sakshi_1
# password-c