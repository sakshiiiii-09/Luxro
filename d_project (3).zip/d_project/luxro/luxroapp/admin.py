from django.contrib import admin

from luxroapp.models import product
# from models import WishItem

class productAdmin(admin.ModelAdmin):
    list_display=['id','name','brand','price','gender','cat','is_active'] 
    list_filter=['cat','is_active']


admin.site.register(product,productAdmin)



